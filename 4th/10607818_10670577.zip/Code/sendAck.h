/**
 *  @author Luca Pietro Borsani
 */

#ifndef SENDACK_H
#define SENDACK_H

//payload of the msg
typedef nx_struct msg_req_t {
	nx_uint16_t type;
	nx_uint16_t counter;
} msg_req_t;

typedef nx_struct msg_res_t {
	nx_uint16_t type;
	nx_uint16_t counter;
	nx_uint16_t value;
} msg_res_t;

#define REQ 1
#define RESP 2 

enum{
AM_MSG = 6,
};

#endif
