
La simulazione usata per compilare il forms è la seguente: simulations.txt



Le altre, che si trovano nella cartella "Simulations for testing", sono state allegate per far osservare il comportamento in caso di ritrasmissione  